# Handoff: Command Center redesign (Strategize × RT Digital)

## Overview
A redesign of the existing Canterbury-pilot client dashboard into a **dark "command center"**: a status-first workspace where you and Chris can see, at a glance, exactly where the project stands, what's blocking it, and who owns what — then drill into the offer, system map, and working plan below.

The redesign keeps all existing content and the existing AI Project Chat, but:
- **Reorders the page** so live status leads and the hero moves down.
- **Switches the whole theme** from warm paper to a near-black, high-contrast dark UI with glowing teal/gold/red accents.
- **Adds four new sections**: a Status Snapshot, an Outstanding board, a Timeline, and a Decisions log + "What changed this week" feed.
- **Fixes the AI chat** so it no longer overlaps the header — it's now a bottom-right launcher that expands into a panel.

## Screenshots
Rendered reference images of the design live in `screenshots/` — use them to match the look without rendering anything:
- `01-status-snapshot.png` — header + Status Snapshot (health / blockers / current stage tiles).
- `02-hero-spotlight.png` — the recommended hero (variation 03) with the metric ticker.
- `03-outstanding-board.png` — the three-lane Outstanding board.
- `04-working-plan.png` — the dark Working Plan checklist (Chris / Jesse columns).
- `05-timeline-decisions.png` — the Timeline track + top of Decisions/Changes.
- `06-decisions-changes.png` — Decisions log + "What changed this week".
- `07-system-map.png` — the 7-step System Map.
- `08-offer-lab.png` — the Offer Lab variance panel.

(The AI chat isn't shown as a still — it's a fixed bottom-right launcher that expands into a panel; see the ProjectChat section for the full spec, and open the HTML reference to interact with it.)

## About the design files
The file in `reference/Command Center.dc.html` is a **design reference built in HTML** — a working prototype that shows the intended look, layout, spacing, colors, type, motion, and interactions. **It is not production code to copy verbatim.** Open it in a browser to see and click the real thing (toggle checklist items, switch hero variations, open the chat).

Your task is to **recreate this design inside the existing Next.js app** (`app/page.tsx`, `app/components/*`, `app/globals.css`), using the app's established patterns: React function components, the `@/lib/collaboration` data + types, `next/font` (Geist + Geist Mono are already configured), and the class-based `globals.css`. Do **not** ship the HTML file directly, and do **not** introduce a new styling library — extend `globals.css` the same way it's written today.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, shadows, and interactions in the reference are final. Match them precisely (exact hex values and the token table below). Where the reference uses inline styles, translate them into `globals.css` classes consistent with the current file.

---

## Design tokens (replace the current `:root` palette in `globals.css`)

```css
:root {
  /* canvas */
  --bg:            #0b0c09;   /* page background (near-black, warm) */
  --bg-alt:        #0e0f0b;   /* alternating section background */
  --panel:         #111310;   /* solid raised panel (hero board, offer panel, chat) */
  --panel-soft:    rgba(255,253,250,0.04);  /* translucent tile fill */
  --panel-hover:   rgba(255,253,250,0.07);  /* tile fill on hover */
  --line:          rgba(255,253,250,0.09);  /* hairline border */
  --line-strong:   rgba(255,253,250,0.14);  /* stronger border */

  /* text */
  --paper:         #fffdfa;   /* primary text */
  --muted:         rgba(255,253,250,0.56);
  --faint:         rgba(255,253,250,0.40);

  /* accents (electric, tuned for dark) */
  --teal:          #34c2b0;   --teal-deep: #1f8f83;
  --gold:          #e7b24c;   --gold-bright: #f0c878;
  --red:           #ec6a5e;   --red-bright: #f0938a;
  --green:         #46c98f;   /* "on track" health only */
}
```

**Type:** Geist (sans) for everything; **Geist Mono** for all kickers/labels, numbers, dates, pills, buttons and nav-status text — this gives the "data dashboard" feel. Both are already wired via `next/font` in `app/layout.tsx` (`--font-geist-sans`, `--font-geist-mono`); set body to the sans var and use `var(--font-geist-mono)` for the mono bits.

**Type treatments**
- Section kicker: Geist Mono, 11px, `letter-spacing:0.18em`, `text-transform:uppercase`, color `--teal` (or `--gold`/`--red` per section).
- Section H2: Geist sans, `font-weight:760`, `letter-spacing:-0.02em`, `line-height:1`, fluid `clamp(28px,3.8vw,48px)`.
- Hero H2: `font-weight:780`, `letter-spacing:-0.03em`, `clamp(34px,5.2vw,68px)`.
- Big metric numbers: `font-weight:800`, `letter-spacing:-0.02em` to `-0.03em`.

**Radii:** big tiles `16–18px`; cards/inputs `10–12px`; buttons `9–10px`; pills/dots `999px`.
**Shadows:** raised solid panels `0 30px 90px rgba(0,0,0,0.5)`; accent glow on a colored element `0 0 16–26px <accent at 0.35–0.5 alpha>`.
**Section padding:** `clamp(40px,6vw,80px)` vertical, `clamp(18px,5vw,72px)` horizontal; inner content `max-width:1340px; margin:0 auto`.
**Backgrounds alternate** `--bg` / `--bg-alt` between sections, each separated by a `1px solid var(--line)` top border.

**Motion (subtle):**
- Status pulse — a ping ring on every "live" dot:
  ```css
  @keyframes ping { 0%{transform:scale(1);opacity:.55} 70%,100%{transform:scale(2.6);opacity:0} }
  ```
  Implement as a dot with an absolutely-positioned sibling ring running `ping 2.2s ease-out infinite`.
- Hover lift on tiles/cards: `transform:translateY(-3px)` + brighter border, `transition:.25s`.
- No entrance animations (they caused flicker — leave them out).

---

## Page order (rewrite `app/page.tsx` composition to this order)

1. **Header** (sticky) — brand lockup left; nav right: `Status · Outstanding · Plan · Timeline · System · Offer`; an **Ask AI** button (opens chat) and a **live health chip** (pulsing dot + `AT RISK · 3 BLOCKERS`, colored by health).
2. **Status Snapshot** `#status` *(NEW — see below)*
3. **Pipeline** — the 7 chevron stages, moved to the top, restyled dark.
4. **Hero** `#top` — moved below status. *(Pick ONE variation — see Hero section.)*
5. **Outstanding board** `#outstanding` *(NEW)*
6. **Working Plan** `#plan` — existing `CollaborationHub`, restyled dark (keep checklist interactivity).
7. **Timeline** `#timeline` *(NEW)*
8. **Decisions log + What changed this week** `#decisions` *(NEW, two columns)*
9. **System Map** `#system` — existing 7-step flow, restyled dark.
10. **Offer Lab** `#offer` — existing copy + variance panel, restyled dark.
11. **Footer** — mono one-liner.
12. **ProjectChat** — fixed bottom-right launcher (restyle + reposition existing component).

> The current `meetingSignals` "Meeting Brief" and the 6-card "Campaign Hypotheses" grid were dropped from the lead experience to keep the snapshot focused. Keep them in the codebase; either fold them lower on the page or behind a tab. Confirm with the owner before deleting.

---

## Sections

### Header
- Sticky, `z-index:50`, `background:rgba(11,12,9,0.72)`, `backdrop-filter:blur(20px)`, bottom border `1px solid var(--line)`, padding `13px clamp(18px,5vw,72px)`.
- **Brand mark:** a 30px circle, `2px solid var(--teal)`, glow `0 0 18px rgba(52,194,176,0.4)`, with a small concentric 10px ring inside (mimics the Strategize target logo). Followed by mono text `STRATEGIZE × RT DIGITAL`. (If you have the real logo PNGs from the current build at `/strategize-transparent.png` and `/rt-digital-transparent.png`, you may use those instead — but they're light-on-light, so the CSS mark reads better on dark.)
- **Nav links:** Geist Mono-ish, 12.5px, `color:var(--muted)`, hover `--paper`.
- **Ask AI button:** pill, `border:1px solid var(--line-strong)`, `background:var(--panel-soft)`, mono 11px, with a glowing teal dot; opens the chat.
- **Health chip:** pill tinted by health state (`rgba(<accent>,0.12)` bg, `0.32` border), a pulsing dot, and mono text `<STATE> · <n> BLOCKERS`.

### Status Snapshot `#status` *(NEW — the centerpiece)*
Header row: kicker `LIVE STATUS · CANTERBURY PILOT`, H1 `Where the pilot stands, right now.`, right-aligned mono `UPDATED TODAY · <date>`.

**Row 1 — three large tiles** (`grid; repeat(auto-fit,minmax(290px,1fr)); gap:14px`):
1. **Project Health** — radial accent glow `radial-gradient(120% 120% at 100% 0%, <healthGlow>, transparent 62%)` over `--panel-soft`; border tinted by health. Big status word (`AT RISK`) in the health color with a pulsing dot; sub-line; a 3-dot legend `ON TRACK / AT RISK / BLOCKED`.
2. **Blockers** — red radial glow + `1px solid rgba(236,106,94,0.3)`. Big count (`3`) in `--red`, "open · gating creative", a mono `ALL ON CHRIS` chip, then a bulleted peek of the blocker titles.
3. **Current Stage** — teal radial glow. `Onboarding` + mono `02 / 07`; a progress bar (`height:6px`, fill `28%`, `linear-gradient(90deg,var(--teal),var(--teal-deep))`, glow); footer mono `NEXT · STRATEGY` / `JUL 4 · 6 DAYS`.

**Row 2 — four small tiles** (`grid; repeat(auto-fit,minmax(200px,1fr))`), each `--panel-soft`, `1px solid var(--line)`, **3px left accent border**, mono kicker, 38px number, sub-line:
- `AWAITING CLIENT` → count of incomplete Chris items (gold accent).
- `AWAITING YOU` → count of incomplete Jesse items (teal accent).
- `OPEN ACTIONS` → `<open>/<total>` with `<done> done` (neutral accent).
- `DAYS TO LAUNCH` → number + `target <date>` (gold accent).

### Pipeline (chevron stages)
- Horizontal flex row, `gap:7px`, `overflow-x:auto`; centered mono kicker `DELIVERY PIPELINE` above.
- Each stage is a chevron via `clip-path` (the middle shape, with flat left edge on the first and flat right edge on the last):
  - middle: `polygon(0 0, calc(100% - 20px) 0, 100% 50%, calc(100% - 20px) 100%, 0 100%, 20px 50%)`
  - first: drop the trailing `20px 50%` point; last: `polygon(0 0,100% 0,100% 100%,0 100%,20px 50%)`.
- States: **done** → teal gradient `linear-gradient(180deg,#247f76,#1b665e)`, light text, solid light dot. **current** → gold gradient `linear-gradient(180deg,#ecb750,#cf9a36)`, dark text, glow `0 0 26px rgba(231,178,76,0.4)`, dark dot. **next** → translucent fill, gold ring dot, gold inset border. **todo** → faint fill, faint ring dot.
- Stages in order: `PRE-ONBOARDING`(done) · `ONBOARDING`(current) · `STRATEGY`(next) · `CREATIVE` · `BUILD` · `LAUNCH` · `OPTIMISE`.

### Hero `#top`
The reference includes **three variations** behind a switcher so the owner could choose. **Ship ONE** (recommend **03 Spotlight**, currently the default). Keep the others only if you want a config flag; otherwise delete the switcher and the unused two.
- **01 Statement** — two columns: left big headline + CTAs; right a glowing teal thesis card (`Free Business Gap Analysis`) with the four pilot metrics as a 2×2.
- **02 Split board** — left headline + intro + CTAs; right a dark "Pilot snapshot" board (metric tiles + gap-card), echoing the original hero board but dark/glowing.
- **03 Spotlight** *(recommended)* — centered: a soft teal radial glow behind a centered headline, centered CTAs, then a horizontal "ticker" row of pill chips (the 4 metrics + `Free Business Gap Analysis`).
- Shared copy — headline: *"Clarify the offer, shape the campaign, and move trade owners from ad click to booked consult."* CTAs: `Open Working Plan` (primary, teal fill, glow), `Ask AI Chat` (opens chat), `View System Map` (ghost).
- Metrics: `5–25` staff sweet spot · `$875` benchmark value · `$100K+` gap story · `1 in 5` conversion benchmark.
- CTA primary style: `background:var(--teal); color:var(--bg); box-shadow:0 0 26px rgba(52,194,176,0.35)`. Ghost: `1px solid var(--line-strong)` on `--panel-soft`.

### Outstanding board `#outstanding` *(NEW)*
Kicker `OUTSTANDING`, H2 *"What's blocking, and who's holding it."* Three lanes (`grid; repeat(auto-fit,minmax(280px,1fr))`), each a panel with a header (colored dot + glow, mono title, count) and a stack of cards:
- **Blocking now** (red) — incomplete items flagged as blockers.
- **Awaiting client** (gold) — incomplete Chris items that aren't blockers.
- **On you** (teal) — incomplete Jesse items.
- **Card:** `--panel-soft`, `1px solid var(--line)`, **3px left border in the lane color**, title (15px/600), detail (12.5px/muted), then a footer row: owner avatar (20px circle, initials `CM`/`JA`, tinted by owner) + owner name, and a mono age (`4d`). Hover lift.

### Working Plan `#plan` (restyle existing `CollaborationHub`)
- Keep the toggle behavior and the `ChecklistItem`/`ChecklistOwner` model. Header: kicker `WORKING PLAN`, H2 *"What happens next, and who owns what."*, plus a gold `WORKING DRAFT CHECKLIST` pill.
- Two columns (Chris / Jesse), each a panel with a header (`<name> action items` + mono `x/y complete` in teal) and rows.
- **Row (label/checkbox):** `grid-template-columns:26px 1fr; gap:13px`, `--panel-soft` bg, hover `--panel-hover`. The native checkbox is visually hidden; a custom 24px box shows — unchecked: `2px solid rgba(255,253,250,0.28)` transparent; **checked: filled `var(--teal)`, dark `✓`**, row bg shifts to `rgba(52,194,176,0.08)`, title goes muted + strikethrough.
- Toggling an item must also update the snapshot counts (Awaiting / Open actions) and, ideally, health — so derive those from the same items state (see State Management).

### Timeline `#timeline` *(NEW)*
Kicker `TIMELINE`, H2 *"From kickoff to launch."* A horizontal track (`min-width:760px`, `overflow-x:auto`) with a 2px gradient line behind 7 nodes (`flex:1 0 0` each). Each node: a 14px dot pinned to the line + a stacked label block below — mono date, bold label, muted note. Dot states: **done** teal filled (glow), **current** gold filled (stronger glow), **upcoming** hollow (`2px` faint ring). Dates/notes:
`Pre-onboarding JUN 20 done "Access + scope agreed"` · `Onboarding JUN 28 current "Workspace + CRM live"` · `Strategy JUL 4 "Offer + segments lock"` · `Creative JUL 14 "Scripts + gap teaser"` · `Build JUL 24 "Funnel + automations"` · `Launch AUG 8 "Meta + Google live"` · `Optimise ONGOING "Qualify + tune"`.

### Decisions + What changed `#decisions` *(NEW, two columns)*
- **Decisions log** (left) — kicker teal `DECISIONS LOG`, H2 *"What we've locked."* A vertical list on a `2px` teal left rail; each entry a teal glowing node + mono date + line of copy:
  - `JUN 27` Lead with the benchmark gap-analysis offer — not subsidies or grants.
  - `JUN 27` Start in Christchurch / Canterbury before any national rollout.
  - `JUN 27` Qualify only owners with staff (5–25), real turnover and strategic pain.
  - `JUN 26` Keep proprietary benchmark numbers out of the ad creative.
- **What changed this week** (right) — kicker gold, H2 *"Latest movement."* A stack of feed cards (`--panel-soft`), each with a glowing status dot (teal = progress, red = flag) + text:
  - (teal) Onboarding kicked off — shared workspace and CRM access granted.
  - (teal) GHL two-step landing funnel drafted and staged.
  - (teal) CRM disqualifiers defined (one-person, no staff, low turnover, dupes).
  - (red) Blocked on Chris for anonymised benchmark proof assets.

### System Map `#system` (restyle existing)
Kicker `SYSTEM MAP`, H2 *"Lead to booked consult."* Seven cards (`grid; repeat(auto-fit,minmax(160px,1fr))`): a circular numbered badge filled with the step's accent color + glow, title, detail. Hover lift. Steps/accents: `01 Traffic`(teal) · `02 Lead Capture`(gold) · `03 TradeAI CRM`(teal) · `04 AI Nurture`(teal) · `05 Qualification`(red) · `06 Booked Consult`(gold) · `07 Human Handoff`(light). Copy is unchanged from the current `systemSteps`.

### Offer Lab `#offer` (restyle existing)
Two columns: left kicker + H2 *"The campaign should sell the size of the hidden gap."* + the existing paragraph. Right a solid `--panel` panel: header (`CREATIVE TERRITORY` / `Gap Analysis Teaser`), three variance rows (label + big red figure: `$200K missing` highlighted with a red left-to-transparent wash, `$116K over line`, `$64K above benchmark`), then a glowing teal teaser-script box with the quote.

### ProjectChat (restyle + reposition existing component)
Keep all existing logic — `/api/project-chat`, `/api/knowledge-status`, `/api/knowledge-sync`, starter questions, message/source rendering. **Change only presentation + placement:**
- Move from the centered top bar to a **fixed bottom-right** stack: `position:fixed; right:22px; bottom:22px; z-index:60`.
- Collapsed = a pill **launcher** ("ASK THE PROJECT BRAIN", glowing teal dot). This removes the header overlap entirely.
- Expanded = a `min(400px, calc(100vw - 32px))` panel above the launcher: header with a teal radial wash + close `×`; scrolling messages (`max-height:min(380px,46vh)`); assistant bubble `rgba(255,253,250,0.06)`, user bubble `var(--teal)` dark text; starter-question chips (teal-tinted pills); input row with a teal `ASK` button.
- Keep the `indexed / not searchable` knowledge status line in the expanded header.

---

## Interactions & behavior
- **Checklist toggle** updates item state and, derived from it, the snapshot's Awaiting/Open counts (and health if you auto-derive it).
- **Hero switcher** (only if you keep it) sets which hero variation renders.
- **Ask AI** button, the hero `Ask AI Chat` CTA, and the launcher all open the chat panel; `×` closes it. Submitting a question or tapping a starter posts to `/api/project-chat` (unchanged).
- **Hover** lifts tiles/cards and brightens borders. **Live dots** pulse continuously.
- **Anchor nav** smooth-scrolls (`html{scroll-behavior:smooth}`) to the section ids above.

## State management
- `items: ChecklistItem[]` — extend the model with `blocker: boolean` and an optional `age: string`. Lives in (or above) the Working Plan; the Snapshot and Outstanding board read from the same source so everything stays in sync.
- Derived (compute, don't store): `blockerCount`, `awaitingClient`, `awaitingYou`, `openActions`, `doneActions`.
- `health` — recommend **auto-deriving**: `blockerCount > 0 ? "At risk" : "On track"` (and `"Blocked"` if you add a hard-stop flag). Drives the header chip + health tile color/copy. Health color map: On track `--green`, At risk `--gold`, Blocked `--red`.
- Chat state is unchanged from the current `ProjectChat` (`isOpen`, `messages`, `question`, `isLoading`, knowledge status).
- New static content (`decisions`, `changes`, `timeline`, blocker flags) should live in `@/lib/collaboration` next to `defaultChecklistItems` / `projectStages` so it's all editable in one place and easy to feed real data into later.

## Data you'll want to make real (currently sensible placeholders)
Dates and counts are plausible defaults — wire these to your source of truth:
- Timeline dates + `DAYS TO LAUNCH` (`41`, target `AUG 8`) and `NEXT · STRATEGY JUL 4 · 6 DAYS`.
- The single confirmed real blocker is **"anonymised benchmark screenshots from Chris."** The other two blockers (offer language, first 3 segments) and the "what changed" items were inferred from the brief — confirm or replace.

## Files
- `reference/Command Center.dc.html` — the full working design reference (open in a browser).
- Existing files to modify: `app/page.tsx`, `app/components/CollaborationHub.tsx`, `app/components/ProjectChat.tsx`, `app/globals.css`, and `@/lib/collaboration`.
- New components to add (suggested): `StatusSnapshot.tsx`, `Pipeline.tsx`, `OutstandingBoard.tsx`, `ProjectTimeline.tsx`, `DecisionsAndChanges.tsx`.

## Implementation order (suggested)
1. Swap the `:root` palette + body background in `globals.css`; set Geist Mono for labels. (Instant ~80% of the new feel.)
2. Reorder `page.tsx` to the new section order; move the hero down.
3. Restyle the existing sections dark (Pipeline/stage-cue, CollaborationHub, System Map, Offer Lab, header).
4. Reposition + restyle `ProjectChat` to the bottom-right launcher.
5. Build the four new sections (Status Snapshot, Outstanding, Timeline, Decisions/Changes) + their data in `@/lib/collaboration`.
6. Derive health + snapshot counts from the shared `items` state.
